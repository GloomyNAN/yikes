<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('boston')) {$zbp->ShowError(48);die();}
$blogtitle=$zbp->theme.'主题配置';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';

if(isset($_POST['boston'])){
	$y=$zbp->Config('boston')->custom_color;
	foreach($_POST['boston'] as $key=>$val){
	   $zbp->Config('boston')->$key = $val;
	}
	$zbp->SaveConfig('boston');
	$h=$zbp->Config('boston')->custom_color;
	$strContent = @file_get_contents($zbp->usersdir . 'theme/boston/style/style.css');
	if($y=='' && $h!=''){
		$strContent = str_replace(":#d65456;/*ZDY*/", ':'.$h.";/*ZDY*/", $strContent);
	}elseif($h==''){
		$strContent = str_replace(':'.$y.";/*ZDY*/", ":#d65456;/*ZDY*/", $strContent);
	}else{
		$strContent = str_replace(':'.$y.";/*ZDY*/", ':'.$h.";/*ZDY*/", $strContent);
	}
	@file_put_contents($zbp->usersdir . 'theme/boston/style/style.css', $strContent);
	$zbp->ShowHint('good');
}
if ($zbp->CheckPlugin('UEditor')) {
	echo '<script type="text/javascript" src="' . $zbp->host . 'zb_users/plugin/UEditor/ueditor.config.php"></script>';
	echo '<script type="text/javascript" src="' . $zbp->host . 'zb_users/plugin/UEditor/ueditor.all.min.js"></script>';
	echo '<style type="text/css">#editor_content{height:auto}</style>';
}
?>
<link rel="stylesheet" href="script/color/colorpicker.css" type="text/css" />
<script type="text/javascript" src="script/color/colorpicker.js"></script>
<div id="divMain">
	<div class="divHeader"><?php echo $blogtitle;?></div>
  	<div class="SubMenu"></div>
	<div id="divMain2">
	<form id="form1" name="form1" method="post">	
    <table width="100%" style='padding:0px;margin:0px;' cellspacing='0' cellpadding='0' class="tableBorder">
  <tr>
    <th width='20%'><p align="center">基本设置</p></th>
    <th width='60%'><p align="center">内容</p></th>
    <th width='20%'><p align="center">扩展</p></th>
  </tr>
  <tr>
    <td><b><label for="header_fixed"><p align="center">导航跟随</p></label></b></td>
    <td colspan="2"><p><input id="header_fixed" name="boston[header_fixed]" type="text" value="<?php echo $zbp->Config('boston')->header_fixed;?>" class="checkbox"/></p></td>
  </tr>
  <tr>
    <td><b><label for="custom_logo"><p align="center">网站LOGO</p></label></b></td>
    <td><p align="left"><input name="boston[custom_logo]" id="custom_logo" type="text"  class="uplod_img"  style="width: 90%;" value="<?php echo $zbp->Config('boston')->custom_logo;?>" /> <a href="javascript:;" onclick="document.getElementById('custom_logo').value='';" style="font-size:12px;">X</a></p></td>
    <td><p>点击左侧输入框弹出上传窗口</p></td>
  </tr>
  <tr>
    <td><b><label for="custom_color"><p align="center">网站颜色</p></label></b></td>
    <td><p align="left"><input name="boston[custom_color]" id="custom_color" type="text" class="color"  style="width:100px;" value="<?php echo $zbp->Config('boston')->custom_color;?>" /> <a href="javascript:;" onclick="document.getElementById('custom_color').value='';document.getElementById('custom_color').style.backgroundColor='#ffffff'" style="font-size:12px;">X</a></p></td>
    <td><p></p></td>
  </tr>
  <tr>
    <td><b><label for="layout"><p align="center">侧栏位置</p></label></b></td>
    <td><p align="left">
    <select style="width:180px;" name="boston[layout]" id="layout">
  	<option value="left-layout"<?php echo $zbp->Config('boston')->layout=='left-layout'?' selected="selected"':''?>>左侧</option>
  	<option value="right-layout"<?php echo $zbp->Config('boston')->layout=='right-layout'?' selected="selected"':''?>>右侧</option>
   	</select>
    </p></td>
    <td><p></p></td>
  </tr>
  <tr>
	<td><b><label for="head_img_id"><p align="center">头部图片</p></label></b></td>
	<td><p align="left">
	<select style="width:180px;" name="boston[head_img_id]" id="head_img_id">
	<option value="0"<?php ($zbp->Config('boston')->head_img_id==0)?' selected="selected"':''?>>不显示</option>
	<?php echo OutputOptionItemsOfCategories($zbp->Config('boston')->head_img_id); ?>
    </select>
    <select style="width:180px;" name="boston[head_img_order]" id="head_img_order">
	<option value="0"<?php ($zbp->Config('boston')->head_img_order==0)?' selected="selected"':''?>>按时间排序</option>
  	<option value="1"<?php ($zbp->Config('boston')->head_img_order==1)?' selected="selected"':''?>>按浏览量排序</option>
  	<option value="2"<?php ($zbp->Config('boston')->head_img_order==2)?' selected="selected"':''?>>按ID排序</option>
   	</select>
	</p></td>
	<td><p></p></td>
  </tr>
  <tr>
    <td><b><label for="foot_img_order"><p align="center">底部图片</p></label></b></td>
    <td><p align="left">
    <select style="width:180px;" name="boston[foot_img_id]" id="foot_img_id">
	<option value="0"<?php ($zbp->Config('boston')->foot_img_id==0)?' selected="selected"':''?>>不显示</option>
	<?php echo OutputOptionItemsOfCategories($zbp->Config('boston')->foot_img_id); ?>
    </select>
    <select style="width:180px;" name="boston[foot_img_order]" id="foot_img_order">
	<option value="0"<?php ($zbp->Config('boston')->foot_img_order==0)?' selected="selected"':''?>>按时间排序</option>
  	<option value="1"<?php ($zbp->Config('boston')->foot_img_order==1)?' selected="selected"':''?>>按浏览量排序</option>
  	<option value="2"<?php ($zbp->Config('boston')->foot_img_order==2)?' selected="selected"':''?>>按ID排序</option>
   	</select>
    </p></td>
    <td><p></p></td>
  </tr>
  <tr>
    <td><b><label for="foot_sidebar"><p align="center">底部模块</p></label></b></td>
    <td><p><input id="foot_sidebar" name="boston[foot_sidebar]" type="text" value="<?php echo $zbp->Config('boston')->foot_sidebar;?>" class="checkbox"/></p></td>
    <td><p>将模块拉到侧栏2</p></td>
  </tr>
  <tr>
    <td><b><label><p align="center">侧栏分布</p></label></b></td>
    <td colspan="2"><p>底部模块：侧栏2、首页及分类页：侧栏3、作者页面：侧栏4、文章及单页：侧栏5、其他页面：默认侧栏</p></td>
  </tr>
</table>
 <br />
   <input name="" type="Submit" class="button" value="保存"/>
    </form>
<br />
	</div>
</div>
<script type="text/javascript">
	ActiveTopMenu("topmenu_boston");
$(document).ready(function () {
	if ($('.color').length>0) {
		$('.color').ColorPicker({
			onSubmit: function(hsb, hex, rgb, el) {
				$(el).val('#'+hex);
				$(el).css("background-color",'#'+hex);
				$(el).ColorPickerHide();
			},
			onBeforeShow: function () {
				$(this).ColorPickerSetColor(this.value);
			}
		}).bind('keyup', function(){
			$(this).ColorPickerSetColor(this.value);
		});
	}
});
</script>
<?php
if ($zbp->CheckPlugin('UEditor')) {
	echo "<script type=\"text/javascript\" src=\"script/lib.upload.js\"></script>";
}
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>