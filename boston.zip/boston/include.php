<?php
#注册插件
RegisterPlugin("boston","ActivePlugin_boston");

function ActivePlugin_boston() {
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu','boston_add_topmenu');//顶部主题配置按钮
}
function InstallPlugin_boston() {
	global $zbp;
	if(!$zbp->HasConfig('boston')){
		$array = array(
			'version'			=>	1,
			'custom_color'		=>	'',//自定义颜色
			'header_fixed'		=>	1,//顶部导航跟随
			'custom_logo'		=>	'',//自定义logo
			'layout'			=>	'right-layout',//侧栏位置
			'head_img_id'		=>	0,//头部图片ID
			'head_img_order'	=>	0,//头部图片排序
			'foot_sidebar'		=>	1,//底部模块
			'foot_img_id'		=>	0,//底部图片ID
			'foot_img_order'	=>	0,//底部图片排序
				
		);
		foreach($array as $key=>$val){
			$zbp->Config('boston')->$key = $val;
		}
		$zbp->SaveConfig('boston');
	}
}
function UninstallPlugin_boston() {}
function boston_add_topmenu(&$m){
	global $zbp;
	array_unshift($m, MakeTopMenu("root",'主题配置',$zbp->host . "zb_users/theme/boston/main.php","","topmenu_boston"));

}
//获取缩略图
function boston_get_thumbs($as) {
    global $zbp;
    $img_src = '';
    $pattern='/<img.*?src="(.*?)(?=")/';
    preg_match_all($pattern,$as,$matchContent);
    if  (isset($matchContent[1][0])) {
        $temp=$matchContent[1][0];
    } else {
        $temp= $zbp->host . "zb_users/theme/boston/style/img/default_thumb.png";
    }
    $img_src .= $temp;
    return $img_src;
}
function boston_get_head_img(){
	global $zbp;
	$array=array();
	if($zbp->Config('boston')->head_img_order==1){
		$order=array('log_ViewNums' => 'desc');
	}elseif($zbp->Config('boston')->head_img_order==2){
		$order=array('log_ID' => 'desc');
	}else{
		$order=array('log_PostTime' => 'desc');
	}
	$sql=$zbp->db->sql->get()
			 ->select($zbp->table['Post'])
			 ->where(
					array(
						array('=', 'log_Type', 0),
						array('=', 'log_Status', 0),
						array('IN', 'log_CateID', boston_get_sub_cate($zbp->Config('boston')->head_img_id))
					)
				)
			 ->orderBy($order)
			 ->limit(8)
			 ->sql;
	$array = $zbp->GetListType('Post', $sql);
	if(count($array)>0){
		foreach($array as $post){
			echo '<article id="post-'.$post->ID.'" class="post-'.$post->ID.' post type-post status-publish format-standard has-post-thumbnail hentry category-culture category-lifestyle category-travel">';
			echo '	<aside class="entry-thumbnail"> <a href="'.$post->Url.'" title="'.$post->Title.'"> <img width="500" height="350" src="'.boston_get_thumbs($post->Content).'" class="attachment-boston-pro-featured-medium size-boston-pro-featured-medium wp-post-image" alt="'.$post->Title.'" /> </a> </aside>';
			echo '	<header class="entry-header"> <a class="featured-posts-cate" href="'.$post->Category->Url.'">'.$post->Category->Name.'</a>';
			echo '	  <h2 class="entry-title"><a href="'.$post->Url.'" rel="bookmark">'.$post->Title.'</a></h2>';
			echo '	</header>';
			echo '	<!-- .entry-header --> ';
			echo '</article>';
			echo '<!-- #post-## -->';
		}
	}
}
function boston_get_foot_img(){
	global $zbp;
	$array=array();
	if($zbp->Config('boston')->foot_img_order==1){
		$order=array('log_ViewNums' => 'desc');
	}elseif($zbp->Config('boston')->foot_img_order==2){
		$order=array('log_ID' => 'desc');
	}else{
		$order=array('log_PostTime' => 'desc');
	}
	$sql=$zbp->db->sql->get()
			 ->select($zbp->table['Post'])
			 ->where(
					array(
						array('=', 'log_Type', 0),
						array('=', 'log_Status', 0),
						array('IN', 'log_CateID', boston_get_sub_cate($zbp->Config('boston')->foot_img_id))
					)
				)
			 ->orderBy($order)
			 ->limit(8)
			 ->sql;
	$array = $zbp->GetListType('Post', $sql);
	if(count($array)>0){
		foreach($array as $post){
			echo '<li><a href="'.$post->Url.'"><img src="'.boston_get_thumbs($post->Content).'" alt="'.$post->Title.'" /></a></li>';
		}
	}
}
//获取分类的子分类IDm（包含自身）
function boston_get_sub_cate($cate_id){
	global $zbp;
	$arysubcate = array();
	if($cate_id){
		$arysubcate[] = $cate_id;
		foreach ($zbp->categorys[$cate_id]->SubCategorys as $subcate) {
			$arysubcate[] = $subcate->ID;
		}
	}
	return $arysubcate;
}