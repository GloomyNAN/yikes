{* Template Name:列表页单条置顶文章 *}
<article id="post-{$article.ID}" class="post-{$article.ID} post post-top type-post status-publish format-standard has-post-thumbnail hentry category-culture category-lifestyle category-travel">
	<h2 class="entry-title"><a href="{$article.Url}" rel="bookmark">[置顶] {$article.Title}</a></h2>
</article><!-- #post-## -->