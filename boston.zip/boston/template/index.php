{* Template Name:首页及列表页 *}
{template:header}
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="archive__layout1">
				{foreach $articles as $article}
					{if $article.IsTop}
						{template:post-istop}
					{else}
						{template:post-multi}
					{/if}
				{/foreach}
			</div> <!-- .archive__default -->
			<div id="infinite-handle">{template:pagebar}</div>
		</main><!-- #main -->
	</div><!-- #primary -->
	<aside id="secondary" class="sidebar widget-area" role="complementary">
		{if $type=='index' || $type=='category'}
			{template:sidebar3}
		{elseif $type=='author'}
			{template:sidebar4}
		{else}
			{template:sidebar}
		{/if}
	</aside>
{template:footer}
