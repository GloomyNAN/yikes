{* Template Name:所有评论模板 *}
{if $socialcomment}
{$socialcomment}
{else}
<div id="comments" class="comments-area">
<div class="comments-title"> <span class="comment_number_count"> 评论列表： （共{$article.CommNums}条评论）</span> </div>
<ol class="comment-list">
<label id="AjaxCommentBegin"></label>
<!--评论输出-->
{foreach $comments as $key => $comment}
{template:comment}
{/foreach}
<label id="AjaxCommentEnd"></label>
</ol>
<!-- .comment-list -->
<!--评论翻页条输出-->
<div id="infinite-handle">{template:pagebar}</div>
<!--评论框-->
{template:commentpost}
</div>
{/if}