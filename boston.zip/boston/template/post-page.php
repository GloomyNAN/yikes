{* Template Name:页面页页面内容 *}
<article id="post-{$article.ID}">
	<header class="entry-header">
		<h1 class="entry-title">{$article.Title}</h1>
	</header><!-- .entry-header -->
	<div class="entry-content">
		{$article.Content}
	</div><!-- .entry-content -->
</article>
{if !$article.IsLock}
{template:comments}
{/if}