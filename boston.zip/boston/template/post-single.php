{* Template Name: 文章页文章内容 *}
<article id="post-36" class="post-36 post type-post status-publish format-standard has-post-thumbnail hentry category-culture category-lifestyle category-travel">
	<header class="entry-header">
		<h1 class="entry-title">{$article.Title}</h1>
		<div class="entry-meta">
			<span class="entry-cate"><a class="entry-category" href="{$article.Category.Url}">{$article.Category.Name}</a></span>
			<span class="author vcard"><a class="url fn n" href="{$article.Author.Url}">{$article.Author.StaticName}</a></span>
			<span class="entry-date"><time class="entry-date published">{$article.Time('Y年m月d日')}</time></span>
			<span class="comments-link"><i class="genericon genericon-comment"></i><a href="{$article.Url}#respond">{$article.CommNums}</a></span>		
		</div><!-- .entry-meta -->
	</header>
	<!-- .entry-header -->
	<div class="entry-content">
		{$article.Content}
	</div>
	<!-- .entry-content -->
	{if $article.Tags}
	<footer class="entry-footer">
		<span class="cat-links">Tags: {foreach $article.Tags as $tag}<a href="{$tag.Url}">{$tag.Name}</a>，{/foreach}</span>
	</footer>
	{/if}
	<!-- .entry-footer -->
</article>
<!-- #post-## -->
{if !$article.IsLock}
{template:comments}
{/if}