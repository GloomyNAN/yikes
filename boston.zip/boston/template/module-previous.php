{foreach $articles as $article}
<li class="has-thumb">
	<a href="{$article.Url}" title="{$article.Title}"><img src="{boston_get_thumbs($article.Content)}" class="attachment-thumbnail size-thumbnail wp-post-image" alt="{$article.Title}" /></a>
	<div class="p-info">
		<h2 class="entry-title"><a title="{$article.Title}" href="{$article.Url}" rel="bookmark">{$article.Title}</a></h2>
		<span class="entry-date"><time class="entry-date published">{$article.Time('Y年m月d日')}</time></span> 
	</div>
</li>
{/foreach}