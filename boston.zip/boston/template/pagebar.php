{* Template Name:分页 *}
{if $pagebar}
{if $pagebar.PageNow-$pagebar.PagePrevious>0}
<a class="previous-page" href="{$pagebar.prevbutton}"><span>上一页</span></a>
{/if}
{foreach $pagebar.buttons as $k=>$v}
  {if $pagebar.PageNow==$k}
	<span class="page now-page">{$k}</span>
  {else}
	<a href="{$v}" class="pages"><span class="page">{$k}</span></a>
  {/if}
{/foreach}
<a class="pages-num" href="javascript:;"><span>{$pagebar.PageNow} / {$pagebar.PageAll}</span></a>
{if $pagebar.PageNow-$pagebar.PageNext<0}
<a clas="next-page" href="{$pagebar.nextbutton}"><span>下一页</span></a>
{/if}
{/if}