			</div><!-- .container -->
		</div><!-- #content -->
	{if $zbp.Config('boston').foot_sidebar}
	<div id="tertiary" class="widget-area footer-widget-area" role="complementary">
		<div class="container">
			{template:sidebar2}
		</div>
	</div> <!-- #tertiary -->
	{/if}
	{if $zbp.Config('boston').foot_img_id>0}
		{if $categorys[$zbp.Config('boston').foot_img_id].Name}
		<div class="footer-instagram-feed widget instagram-feed">
			<ul data-number="8" class="instagram-pics instagram-size-large">
				{boston_get_foot_img()}
			</ul>
			<a class="instagram-button" href="{$categorys[$zbp.Config('boston').foot_img_id].Url}" rel="me">{$categorys[$zbp.Config('boston').foot_img_id].Name}</a>
		</div>
		{/if}
	{/if}
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="container">
			<div class="site-info">
				<p>{$copyright}</p>
			</div>
			<!-- .site-info -->
			<div class="theme-info">
				<span class="theme-info-text">Powered By {$zblogphpabbrhtml} Boston Theme by <a href="http://www.huisem.com/">恒辉建站工作室</a></span>
			</div>
		</div>
	</footer> <!-- #colophon -->
</div><!-- #page -->
<script type="text/javascript" src="{$host}zb_users/theme/{$theme}/script/owl.carousel.min.js?ver=1.3.3"></script>
<script type="text/javascript">
/* <![CDATA[ */
var boston = {"header_fixed":"{$zbp.Config('boston').header_fixed}","slider":{"autoplay":1,"delay":5000,"speed":200}};
/* ]]> */
</script>
<script type="text/javascript" src="{$host}zb_users/theme/{$theme}/script/theme.js?ver=20151215"></script>
{$footer} 
</body>
</html >