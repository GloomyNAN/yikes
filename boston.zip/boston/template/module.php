{* Template Name:单个模块 *}
<section id="{$module.HtmlID}" class="widget widget_{$module.HtmlID}">
	{if (!$module.IsHideTitle)&&($module.Name)}<div class="widget-title">{$module.Name}</div>{else}<div style="display:none;"></div>{/if}
	{if $module.Type=='ul'}
		<ul>{$module.Content}</ul>
	{/if}
	{if $module.Type=='div'}
		<div class="textwidget">{$module.Content}</div>
	{/if}
</section>