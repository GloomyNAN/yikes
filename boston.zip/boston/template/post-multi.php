{* Template Name:列表页普通文章 *}
<article id="post-{$article.ID}" class="post-{$article.ID} post type-post status-publish format-standard has-post-thumbnail hentry category-culture category-lifestyle category-travel">
	<header class="entry-header">
		<h2 class="entry-title"><a href="{$article.Url}" rel="bookmark">{$article.Title}</a></h2>
		<div class="entry-meta">
			<span class="entry-cate"><a class="entry-category" href="{$article.Category.Url}">{$article.Category.Name}</a></span>
			<span class="author vcard"><a class="url fn n" href="{$article.Author.Url}">{$article.Author.StaticName}</a></span>
			<span class="entry-date"><time class="entry-date published">{$article.Time('Y年m月d日')}</time></span>
			<span class="comments-link"><i class="genericon genericon-comment"></i><a href="{$article.Url}#respond">{$article.CommNums}</a></span>		
		</div><!-- .entry-meta -->
	</header><!-- .entry-header -->
	{php}
	$i=$zbp->host.'zb_users/theme/boston/style/img/default_thumb.png';
	$m=boston_get_thumbs($article->Content);
	{/php}
	{if $m!=$i}
	<aside class="entry-thumbnail">
		<a href="{$article.Url}" title="{$article.Title}"><img src="{boston_get_thumbs($article.Content)}" alt="{$article.Title}"></a>
	</aside>
	{/if}
	<div class="entry-summary">
		{$article.Intro}
	</div><!-- .entry-summary -->
	<div class="entry-more">
		<a href="{$article.Url}" title="{$article.Title}">查看全文</a>
	</div>
	<footer class="entry-footer">
		<?php //boston_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->