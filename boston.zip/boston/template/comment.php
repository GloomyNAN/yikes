{* Template Name:单条评论 *}
<li id="comment-{$comment.ID}" class="comment even thread-even depth-{$comment.ID} parent">
<article id="div-comment-{$comment.ID}" class="comment-body">
  <footer class="comment-meta">
	<div class="comment-author vcard"> <img alt="{$comment.Author.StaticName}" src="{$comment.Author.Avatar}" srcset="{$comment.Author.Avatar}" class="avatar avatar-42 photo" height="42" width="42" /> <b class="fn"><a href="{$comment.Author.HomePage}" rel="external nofollow" class="url">{$comment.Author.StaticName}</a></b><span class="says">说道：</span> </div>
	<!-- .comment-author -->
	<div class="comment-metadata"><a href="{$article.Url}#comment-1"><time datetime="{$comment.Time()}">{$comment.Time()}</time></a></div>
	<!-- .comment-metadata --> 
	<div class="reply"><a rel="nofollow" class="comment-reply-link" href="#comment" onclick="zbp.comment.reply('{$comment.ID}')" aria-label="回复给{$comment.Author.StaticName}">回复</a></div>
  </footer>
  <!-- .comment-meta -->
  <div class="comment-content">
	{$comment.Content}
  </div>
  <!-- .comment-content -->
</article>
<!-- .comment-body -->
{foreach $comment.Comments as $comment}
<ol class="children">
  {template:comment}
  <!-- #comment-## -->
</ol>
<!-- .children --> 
{/foreach}
</li>
<!-- #comment-## -->