{* Template Name:公共头部 *}
<!DOCTYPE html>
<html xml:lang="{$lang['lang_bcp47']}" lang="{$lang['lang_bcp47']}">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<meta name="generator" content="{$zblogphp}" />
<meta name="renderer" content="webkit">
<title>{$name}-{$title}</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/{$style}.css" type="text/css" media="all"/>
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/genericons/genericons.css" type="text/css" media="all"/>
<script src="{$host}zb_system/script/jquery-2.2.4.min.js" type="text/javascript"></script>
<script src="{$host}zb_system/script/zblogphp.js" type="text/javascript"></script>
<script src="{$host}zb_system/script/c_html_js_add.php" type="text/javascript"></script>
{$header}
{if $type=='index'&&$page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="{$host}zb_system/xml-rpc/?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="{$host}zb_system/xml-rpc/wlwmanifest.xml" />
{/if}
</head>
<body class="home blog {$zbp.Config('boston').layout}">
<div id="page" class="site">
	<header id="masthead" class="site-header" role="banner">
		<div class="site-topbar">
			<div class="container" style="background: #fff;">
				<nav id="site-navigation" class="main-navigation" role="navigation">
					<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">菜单</button>
					<div id="primary-menu" class="menu">
						<ul>
							{module:navbar}
						</ul>
					</div>
				</nav><!-- #site-navigation -->
				<div class="topbar-search">
					<form name="search" method="post" action="{$host}zb_system/cmd.php?act=search">
					    <span class="genericon genericon-search"></span>
					    <input type="text" name="q" id="search" value="" placeholder="敲回车进行搜索..." />
					</form>
				</div>
			</div>
		</div>
		<div class="site-branding">
			<div class="container">
				{if $zbp.Config('boston').custom_logo}
					<a href="{$host}" class="custom-logo-link" rel="home" itemprop="url"><img src="{$zbp.Config('boston').custom_logo}" class="custom-logo" alt="{$name}" itemprop="logo" /></a>
				{else}
					{if $type='index'}
					<h1 class="site-title"><a href="{$host}" rel="home">{$name}</a></h1>
					{else}
					<p class="site-title"><a href="{$host}" rel="home">{$name}</a></p>
					{/if}
				{/if}
				{if $subname}
				<p class="site-description">{$subname}</p>
				{/if}
			</div>
		</div><!-- .site-branding -->
	</header><!-- #masthead -->
	{if $type=='index'}
	{if $zbp.Config('boston').head_img_id>0}
		{if $categorys[$zbp.Config('boston').head_img_id].Name}
		<div id="featured-content">
		  <div class="site-featured-content">
			<div class="featured_posts">
			  {boston_get_head_img()}
			</div>
		  </div>
		  <!-- .site-feature-content --> 
		</div>
		{/if}
	{/if}
	{else}
		{if $type=='category'}
		<header class="page-header archive-header">
			<div class="container">
				<h1 class="page-title">分类：{$category.Name}</h1>
				{if $category.Intro}<div class="taxonomy-description">{$category.Intro}</div>{/if}
			</div>
		</header><!-- .page-header -->
		{elseif $type=='author'}
		<header class="page-header archive-header">
			<div class="container">
				<h1 class="page-title">作者：{$author.StaticName}</h1>
				{if $author.Intro}<div class="taxonomy-description">{$author.Intro}</div>{/if}
			</div>
		</header><!-- .page-header -->
		{elseif $type=='tag'}
		<header class="page-header archive-header">
			<div class="container">
				<h1 class="page-title">标签：{$tag.Name}</h1>
			</div>
		</header><!-- .page-header -->
		{elseif $type!='article' && $type!='page' && $type!='date'}
		<header class="page-header archive-header">
			<div class="container">
				<h1 class="page-title">{$title}</h1>
			</div>
		</header><!-- .page-header -->
		{/if}
	{/if}
	<div id="content" class="site-content"{if $type=='index'} style="border:none;"{/if}>
		<div class="container">
