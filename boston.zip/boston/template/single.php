{* Template Name:文章页单页 *}
{template:header}
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
		{if $article.Type==ZC_POST_TYPE_ARTICLE}
			{template:post-single}
		{else}
			{template:post-page}
		{/if}
		</main><!-- #main -->
	</div><!-- #primary -->
	<aside id="secondary" class="sidebar widget-area" role="complementary">
		{template:sidebar5}
	</aside>
{template:footer}